<h3 align="center">{{$data['title']}}</h3>
<p>Your verification code for registering PUST Guest House App is: {{$data['code']}}. Never share this code to anyone!</p>
