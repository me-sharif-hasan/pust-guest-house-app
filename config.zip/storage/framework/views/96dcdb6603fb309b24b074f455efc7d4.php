<h3 align="center"><?php echo e($data['title']); ?></h3>
<p>Your verification code for registering PUST Guest House App is: <?php echo e($data['code']); ?>. Never share this code to anyone!</p>
<?php /**PATH C:\Users\Sharif\PhpstormProjects\guesthouse\resources\views/mail-template.blade.php ENDPATH**/ ?>