<?php

namespace App\Exceptions;

use Exception;

class SafeException extends Exception
{
    //
}
